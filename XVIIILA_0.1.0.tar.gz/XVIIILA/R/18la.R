#' Dice game simulation-shr ba la
#'
#' shr ba la , also known as eighteen, wash guava, hi fa,is a common dice gambling game in Taiwan. Sepat Pingpu's original resident language is four, and the four-bar vote is made by four. The equipment used is 4 six-sided dice and a large soup bowl. During the game, players will yell at each other 18, BG, joke like to sing each other, inspire themselves, and play very lively.
#' @param n Number of games
#' @param play_n Number of players
#' @param mode_h broker's dice mode
#' @param mode_g player's dice mode
#' @details
#' dice mode1:every point's Probability is same.
#' dice mode2:point 1 is lower than other point,and point 6 is higher than other point
#' dice mode3:point 6 is lower than other point,and point 1 is higher than other point
#' @return The amount of settlement amount (counts of winning and losing occasions)
#' @references https://zh.wikipedia.org/wiki/%E5%8D%81%E5%85%AB%E4%BB%94
#' @examples
#' n<-100 ##Simulate 100 games
#' play_n<-3
#' ##Three players (excluding broker)
#' mode_h<-2
#' ##The broker chooses the dice of mode2
#' mode_g<-1
#' ##The player chooses the dice of mode1
#' ##game(n, play_n, mode_h, mode_g)
#' ##Game simulation

game<- function(n,play_n,mode_h,mode_g)
{
  play_m=rep(0,play_n+1)
  for (rr in 1:n)
  {
    point_f=rep(0,play_n+1)
    for (k in 1:(play_n+1))
    {   ##包含莊家
      qq=1
      while(qq==1)
      {
        if(k==1)
        {
          point=play_point(mode_h)
        }
        else
        {
          point=play_point(mode_g)  ##骰骰子
        }
        rep_n=point[duplicated(point)==TRUE]##判斷重複值

        if (length(rep_n)==3)
        {
          point_f[k]=13
          qq=0
        }
        else if (length(rep_n)==2)
        {
          if (rep_n[1]>rep_n[2])
          {
            if(rep_n[1]>rep_n[2])
            {
              point_f[k]=rep_n[1]*2
            }
            else
            {
              point_f[k]=rep_n[2]*2

            }
            qq=0
          }

        }
        else if (length(rep_n)==1)
        {
          if (rep_n[1])
          rep_out_l=which(point==rep_n)
          point_out=point[-rep_out_l]
          point_f[k]=sum(point_out)
          qq=0
        }
      }

    }
    for (zz in 1:play_n)
    {
      if (point_f[1]>point_f[zz+1])
      {
        play_m[zz]=play_m[zz]-1
        play_m[play_n+1]=play_m[play_n+1]+1
      }
      else if (point_f[1]<point_f[zz+1])
      {
        play_m[zz]=play_m[zz]+1
        play_m[play_n+1]=play_m[play_n+1]-1
      }
    }
  }
  return(play_m)
}
play_point<- function(mode) {
  d=rep(0,4)
  if (mode == 1) {
    d[1]=sample(1:6,size = 1)
    d[2]=sample(1:6,size = 1)
    d[3]=sample(1:6,size = 1)
    d[4]=sample(1:6,size = 1)
  }
  else if(mode == 2) {
    for (i in 1:4)
    {
      kk=sample(1:120,size = 1)
      if (kk<=15)
        d[i]=1
      else if (kk>15 && kk<=35)
        d[i]=2
      else if (kk>35 && kk<=55)
        d[i]=3
      else if (kk>55 && kk<=75)
        d[i]=4
      else if (kk>75 && kk<=95)
        d[i]=5
      else
        d[i]=6
    }
  }
  else if(mode == 3){
    for (i in 1:4){
      kk=sample(1:120,size = 1)
      if (kk<=15)
        d[i]=6
      else if (kk>15 && kk<=35)
        d[i]=2
      else if (kk>35 && kk<=55)
        d[i]=3
      else if (kk>55 && kk<=75)
        d[i]=4
      else if (kk>75 && kk<=95)
        d[i]=5
      else
        d[i]=1
    }

  }
  return(d)

}
